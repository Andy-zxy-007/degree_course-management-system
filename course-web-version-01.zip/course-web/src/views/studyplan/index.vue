<template>
  <div class="boxing">
    <h4>Study Plan Sandbox</h4>

    <el-row>
        <el-col>
            <el-input v-model="keyword" placeholder="Search for courses"/>
            <el-button type="primary" icon="el-icon-search" plain  @click="search">Search</el-button>
        </el-col>
        <el-col>
            <el-table
                ref="multipleTable"
                :data="courseList"
                tooltip-effect="dark"
                style="width: 100%"
                @selection-change="handleSelectionChange"
                >
                <el-table-column type="selection"></el-table-column>
                <el-table-column label="Subject/Catalogue" width="400">
                    <template slot-scope="scope">{{ scope.row[1].codeValue }} / {{ scope.row[0].catalogue }}</template>
                </el-table-column>
                <el-table-column label="Course name">
                    <template slot-scope="scope">{{ scope.row[0].courseName }}</template>
                </el-table-column>
            </el-table>
            <el-pagination
            @current-change="currentChange"
            :current-page="page"
            :page-size="size"
            layout="total, prev, pager, next, jumper"
            :total="totalElements"
            ></el-pagination>
        </el-col>
    </el-row>
    <el-row>
        <el-col>
            <el-select v-model="year" placeholder="Year">
                <el-option label="Year1" value="Year1"></el-option>
                <el-option label="Year2" value="Year2"></el-option>
                <el-option label="Year3" value="Year3"></el-option>
            </el-select>
            <el-select v-model="term" placeholder="Term">
                <el-option label="Term1" value="Term1"></el-option>
                <el-option label="Term2" value="Term2"></el-option>
                <el-option label="Term3" value="Term3"></el-option>
            </el-select>
            <el-button type="primary" icon="el-icon-search" plain  @click="addToPlan">Add to Plan</el-button>
        </el-col>
    </el-row>

    <el-row>
        <el-col>Your Study Plan</el-col>
    </el-row>
    <el-row>
        <el-col>Year1</el-col>
        <el-col v-show="year1term1">
            <div>Term1</div>
            <div v-for="(item,index) in year1term1" :key="index">
                <span>{{item[1].catalogue}}</span><span>{{item[1].courseName}}</span>
            </div>
        </el-col>
        <el-col v-show="year1term2">
            <div>Term2</div>
            <div v-for="(item,index) in year1term2" :key="index">
                <span>{{item[1].catalogue}}</span><span>{{item[1].courseName}}</span>
            </div>
        </el-col>
        <el-col>
            <div>Term3</div>
            <div v-for="(item,index) in year1term3" :key="index">
                <span>{{item[1].catalogue}}</span><span>{{item[1].courseName}}</span>
            </div>
        </el-col>
    </el-row>
    <el-row>
        <el-col>Year2</el-col>
        <el-col>Term1</el-col>
        <el-col>Term2</el-col>
        <el-col>Term3</el-col>
    </el-row>
    <el-row>
        <el-col>Year3</el-col>
        <el-col>Term1</el-col>
        <el-col>Term2</el-col>
        <el-col>Term3</el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data() {
    return {
        page: 1,
        size: 10,
        totalElements: 1,
        keyword: '',
        year: 'Year1',
        term: 'Term1',
        year1term1:[],
        year1term2:[],
        year1term3:[],
        year2term1:[],
        year2term2:[],
        year2term3:[],
        courseList: [],
        selectedRows: []
    }

  },
  mounted(){

    this.getYear1Term1()
    this.getYear1Term2()
    this.getYear1Term3()
    this.getYear2Term1()
    this.getYear2Term2()
    this.getYear2Term3()
  },

  methods: {
    search(){
    var that = this;
    this.$axios.get("/courses/search",{params:{
        keyvalue: that.keyword,
        page: that.page,
        size: that.size
    }}).then(function(res){
        that.courseList = res.data.data.content;
        that.page = res.data.data.pageable.pageNumber + 1;
        that.totalElements = res.data.data.totalElements;
    }).catch(function(error) {
        console.log(error);
        });
    },

    currentChange(val) {
        this.page = val;
        this.search();
    },

    handleSelectionChange(){

    },

    addToPlan(){
        const list = this.$refs.multipleTable.selection;
        const courseids = [];
        list.forEach(element => {
            courseids.push(element[0].courseId)
        });

        this.$axios.post("/studyplans",{
            list: courseids,
            year: this.year,
            term: this.term,
        }).then(function(res){

        })

    },

    getYear1Term1(){
        var that = this;
        this.$axios.get("studyplans/search",{params:{
            year: 'Year1',
            term: 'Term1'
        }}).then(res=>{
            that.year1term1 = res.data.data
            console.log('result', res.data)
        })
    },
    getYear1Term2(){
        var that = this;
        this.$axios.get("studyplans/search",{params:{
            year: 'Year1',
            term: 'Term2'
        }}).then(res=>{
            that.year1term2 = res.data.data
            console.log('result', res.data)
        })
    },
    getYear1Term3(){
        var that = this;
        this.$axios.get("studyplans/search",{params:{
            year: 'Year1',
            term: 'Term3'
        }}).then(res=>{
            that.year1term3 = res.data.data
            console.log('result', res.data)
        })
    },
    getYear2Term1(){
        var that = this;
        this.$axios.get("studyplans/search",{params:{
            year: 'Year2',
            term: 'Term1'
        }}).then(res=>{
            that.year2term1 = res.data.data
            console.log('result', res.data)
        })
    },
    getYear2Term2(){
        var that = this;
        this.$axios.get("studyplans/search",{params:{
            year: 'Year2',
            term: 'Term2'
        }}).then(res=>{
            that.year2term2 = res.data.data
            console.log('result', res.data)
        })
    },
    getYear2Term3(){
        var that = this;
        this.$axios.get("studyplans/search",{params:{
            year: 'Year2',
            term: 'Term3'
        }}).then(res=>{
            that.year2term3 = res.data.data
            console.log('result', res.data)
        })
    },


  }
}

  </script>